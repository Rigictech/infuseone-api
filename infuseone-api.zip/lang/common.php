<?php 

return [
    'no_record_found' => 'No Record Found',
    'something_went_wrong'=> 'Something Went Wrong',
    'added'           => 'Record Added Successfully',
    'updated'         => 'Record Updated Successfully',
    'deleted'         => 'Record Deleted Successfully',
    'bulk_deleted'    => 'Records Deleted Successfully',
    'status_updated'  => 'Status Updated Successfully',
    'failed'          =>'Something Went Wrong'
]

?>
